#include<stdio.h>
int cube(int x){
	// Tra ve lap phuong cua x
	return x*x*x;
}
// Viet ham tinh lap phuong 1 so kieu double
double cube(double x){
	return x*x*x;
}
int main(){
	/* Nguyen Duy Khanh - 20225019
	   Ma lop: 738919 */
	int n;
	double f;
	scanf("%d %lf", &n, &f);
	printf("Int: %d\n", cube(n));
	printf("Double: %.2lf\n", cube(f));
}
