#include<iostream>
#include<ostream>
#include<math.h>
#include<iomanip>
using namespace std;
struct Complex{
	double real;
	double imag;
};
Complex operator + (Complex a, Complex b){
	Complex res;
	res.real = a.real + b.real;
	res.imag = a.imag + b.imag;
	return res;
}
Complex operator - (Complex a, Complex b){
	Complex res;
	res.real = a.real - b.real;
	res.imag = a.imag - b.imag;
	return res;
}
Complex operator * (Complex a, Complex b){
	Complex res;
	res.real = a.real + b.real + a.imag * b.imag;
	res.imag = a.imag + b.real + a.real * b.imag;
	return res;
}
Complex operator / (Complex a, Complex b){
	Complex res;
	double mau = b.real * b.real + b.imag * b.imag;
	res.real = (a.real * b.real + a.imag * b.imag)/mau;
	res.imag = (a.imag * b.real - a.real * b.imag)/mau;
	return res;
}
ostream& operator << (ostream& out, const Complex &a) { 
    out << '(' << std::setprecision(2) << a.real << (a.imag >= 0 ? '+' : '-') << std::setprecision(2) << fabs(a.imag) << 'i' << ')'; 
    return out; 
}
int main(){
	/* Nguyen Duy Khanh - 20225019
		Ma lop: 738919 */
		
	double real_a, real_b, imag_a, imag_b;
	cin>>real_a>>imag_a;
	cin>>real_b>>imag_b;
	Complex a{real_a, imag_a};
	Complex b{real_b, imag_b};
	cout<<a<<" + "<<b<<" = "<<a+b<<endl;
	cout<<a<<" - "<<b<<" = "<<a-b<<endl;
	cout<<a<<" * "<<b<<" = "<<a*b<<endl;
	cout<<a<<" / "<<b<<" = "<<a/b<<endl;
}
