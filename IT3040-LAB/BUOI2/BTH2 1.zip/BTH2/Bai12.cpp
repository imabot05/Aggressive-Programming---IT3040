/* 
 Bài 2.12. map sort 
*/
 #include <iostream>
 #include <vector>
 #include <algorithm>
 using namespace std;
    struct map {
        int key;
        int value;
    };
    int main() {
        /* Nguyen Duy Khanh - 20225019
           Ma lop : 738919 */
        vector <map> m;
        map tmp;
        char ch = 'a';
        while(ch != 32) {
        cin >> tmp.key >> tmp.value;
        m.push_back(tmp);
        ch = getchar();
    }
    fflush(stdin);
    sort (m.begin(), m.end(), [] (map x, map y) {  
        if (x.value == y.value) return (x.key > y.key);
        else return x.value > y.value; 
    }); 
    for (int i =0 ; i<m.size(); i++) {
        cout <<endl <<m[i].key<<" "<<m[i].value;
    }
 }
