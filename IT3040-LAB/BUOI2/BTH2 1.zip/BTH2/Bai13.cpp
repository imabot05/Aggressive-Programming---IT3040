/* 
 Bai 2.13: Big Integer
 */
 #include <iostream>
 #include <cstring>
 #include <stdlib.h>
 #include <algorithm>
 using namespace std;
 struct bigNum {
    char sign;
    string num;
    };
 // dua do dai hai chuoi ve bang nhau
 void equal_length(string &a, string &b)
 {
    while (a.size() < b.size())
   a = '0' + a;
    while (b.size() < a.size())
   b = '0' + b;
 }
 // xay dung ham tnh tong hai so nguyen duong lon 
string add(string a, string b)
 {
    equal_length(a, b);
    int carry = 0;
    string res;
    for (int i = a.size() - 1; i >= 0; --i)
    {
   // Cong hai chu so cung hang va them bien nho vao hang ben phai neu co
    int d = (a[i] - '0') + (b[i] - '0') + carry;
    carry = d / 10; // bien nho
    res = (char)(d % 10 + '0') + res; // bo sung ket qua cua hang vua tnh vao result
    }    
    if (carry)
        res = '1' + res;        
    return res;
 }
 // xay dung ham tnh hieu cua hai so nguyen duong lon voi dieu kien so a lon hon so b
 string sub(string a, string b)
 {
    equal_length(a, b);
    int d = 0, carry  = 0;
    string res = "";
    for (int i = a.size() - 1; i >= 0; --i) {
        d = (a[i] - '0') - (b[i] - '0') - carry;        
        // Tính toán bien nho cho hàng này.
        if (d < 0){
            carry = 1;
        }
        else carry = 0;        
    res = (char) (d + '0') + res;
    }    
    return res;
 }

 // xay dung ham so sanh hai so nguyen duong lon
 int compare(string a, string b)
 {
    equal_length(a, b);    
    if (a < b) // Có the là a <= b.
        return -1;
    if (a > b) // Có the là a >= b.
        return 1;
    return 0;
 }
 // da nang hoa toan tu + thuc hien phep cong hai so nguyen lon voi dau bat ky
 bigNum operator + (bigNum a, bigNum b) {
    bigNum c;
    if (a.sign == b.sign) {
        c.num = add(a.num, b.num);
        c.sign = a.sign;
    }
    if (compare(a.num, b.num) >= 0) {
        c.num = sub(a.num,b.num);
        c.sign = a.sign;
    }
    else {
        c.num = sub(b.num,a.num);
        c.sign = b.sign;
    }
    return c;
 }
 // da nang hoa toan tu - thuc hien phep tru hai so nguyen lon voi dau bat ky
 bigNum operator - (bigNum a, bigNum b) {
    bigNum d;
    d.num = b.num;
    if (b.sign == '1' ) d.sign = '0';
    else d.sign = '1';
    return a+d;
 }
 // phep nhan mot so nguyen lon voi mot so tu nhien co 1 chu so
 string mut(string a, int n) {
    string res = "";
    if (n==0) res="0";
    else {
    for (int i = 1; i<=n; i++) res = add(res,a);
    }
    return res;
 }

 // da nang hoa toan tu * thuc hien phep nhan hai so nguyen lon voi dau bat ky
bigNum operator * (bigNum a, bigNum b) {
 bigNum c;
 string tmp;
 if (a.sign == b.sign) c.sign ='1';
 else c.sign = '0';
 c.num = "";
 for (int i = b.num.length()-1; i>=0; i--) {
    tmp = mut(a.num, b.num[i]-'0');
 for (int j = 1; j <= b.num.length() -1 - i; j++) {
 tmp = tmp + '0';
 }
 c.num = add (c.num, tmp);
 }
 return c;
 }
 int main(){
 // nhap du lieu vao la hai so nguyen lon Big Integer
 /* Nguyen Duy Khanh - 20225019
    Ma lop: 738919 */ 
 bigNum a,b; 
 cin >> a.sign >> a.num;
 cin >> b.sign >> b.num;
 bigNum c,d;
 c.sign='1'; c.num = "3"; 
 d.sign='1'; d.num = "4";
 // tnh toan ket qua
 bigNum result;
 result = a*b - c*a + d*b;
 cout << result.sign << result.num;
 }
