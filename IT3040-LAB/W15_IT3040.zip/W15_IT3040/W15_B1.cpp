/*  
Bai 4.1 - Tuan 15
Nguyen Duy Khanh - 20225019 - 744469 - 20241  
*/  
#include<iostream>
using namespace std;

struct Node {
	int data;
	Node *next;
	Node(int data){
		this->data = data;
		next = NULL;
	}
};

Node *prepend(Node *head, int data){
	Node *newNode = new Node(data);
	newNode->next = head;
	head = newNode;
	return head;
}

void print(Node *head){
	Node *tmp = head;
	while (tmp != NULL){
		cout << tmp->data << " ";
		tmp = tmp->next;
	}
	cout << endl;
}

Node *reverse(Node *head){
	Node *prev = NULL;
	Node *current = head;
	Node *next = NULL;
	while (current != NULL){
		next = current->next;
		current->next = prev;
		prev = current;
		current = next;
	}
	head = prev;
	return head;
}

int main(){
	/******************** 
	Nguyen Duy Khanh - 20225019  
	Ma lop TH: 744469 
	********************/
	int n, u;
	cin >> n;
	Node *head = NULL;
	for (int i = 0; i < n; i++){
		cin >> u;
		head = prepend(head, u);
	}
	cout << "Original list: ";
	print(head);
	head = reverse(head);
	cout << "Reversed list: ";
	print(head);
	return 0;
}
