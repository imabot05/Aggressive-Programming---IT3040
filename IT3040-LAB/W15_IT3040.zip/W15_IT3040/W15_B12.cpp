/*  
Bai 4.12 - Tuan 15
Nguyen Duy Khanh - 20225019 - 744469 - 20241  
*/ 
#include<iostream>
#include<stack>
using namespace std;
    int h[1000001];
    int left_position[1000001];    // vi tri phan tu khong nho hon o ben trai nhat
    int right_position[1000001];   // vi tri phan tu không nho hon o ben phai nhat
    stack<pair<int, int>> S_right; // luu gia tri và vi tri
    stack<pair<int, int>> S_left;  // luu gia tri và vi tri
int main(){
    int n;
    cin>>n;
    for (int i=0; i<n; i++)
        cin>>h[i];
    for (int i=0; i<n; i++){
        left_position[i] = i;
        while (!S_left.empty()){
            pair<int, int> top = S_left.top();
            if (top.first >= h[i]){
                left_position[i] = top.second;
                S_left.pop();
            } else break;
        }
        S_left.push({h[i], left_position[i]});
    }
    for (int i=n-1; i>=0; i--){
        right_position[i] = i;
        while (!S_right.empty()){
            pair<int, int> top = S_right.top();
            if (top.first >= h[i]){
                right_position[i] = top.second;
                S_right.pop();
            } else break;
        }
        S_right.push({h[i], right_position[i]});
    }
    int max_s=0;
    for (int i=0; i<n; i++){
        int current_s = h[i]*(right_position[i] - left_position[i] + 1);
        max_s = max(max_s, current_s);
    }
    cout<<max_s;
    return 0;
}
/******************** 
Nguyen Duy Khanh - 20225019  
Ma lop TH: 744469 
********************/
