/*  
Bai 4.2 - Tuan 15
Nguyen Duy Khanh - 20225019 - 744469 - 20241  
*/  
#include<iostream>
#include<vector>
#include<cmath>
#include<iomanip>
#include<utility>

using namespace std;
using Point = pair<double, double>;

double area(Point a, Point b, Point c){
	return fabs((a.first * (b.second - c.second) + b.first * (c.second - a.second) + c.first * (a.second - b.second))/2) ; 
} 

int main(){
	/******************** 
	Nguyen Duy Khanh - 20225019  
	Ma lop TH: 744469 
	********************/
	Point p1 = {1, 2};
	Point p2 = {2.5, 10};
	Point p3 = {15, -5.25};
	cout << setprecision(2) << fixed;
	cout << area(p1, p2, p3) << endl;
	return 0;
}