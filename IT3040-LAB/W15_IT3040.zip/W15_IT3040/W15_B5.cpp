/*  
Bai 4.5 - Tuan 15
Nguyen Duy Khanh - 20225019 - 744469 - 20241  
*/  
#include<iostream>
#include<vector>
#include<stack>
#include<list>
#include<algorithm>

using namespace std;
vector<list<int>> adj;

void dfs(vector<list<int>> adj){
	stack<int> S;
	vector<bool> visited(adj.size(), false);
	S.push(1);
	while (!S.empty()){
		int u = S.top();
		if (!visited[u]){
			visited[u] = true;
			cout << u << endl;
		}
		if (!adj[u].empty()){
			int v = adj[u].front();
			adj[u].pop_front();
			if (!visited[v]){
				S.push(v);
			}
		} else {
			S.pop();
		}
	}
}

int main(int argc, const char **argv){
	/******************** 
	Nguyen Duy Khanh - 20225019  
	Ma lop TH: 744469 
	********************/
	int n = 7;
	vector<list<int>> adj;
	adj.resize(n + 1);
	adj[1].push_back(2);
	adj[2].push_back(4);
	adj[1].push_back(3);
	adj[3].push_back(4);
	adj[3].push_back(5);
	adj[5].push_back(2);
	adj[2].push_back(7);
	adj[6].push_back(7);
	dfs(adj);
	return 0;
}