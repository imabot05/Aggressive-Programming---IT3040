/*  
Bai 4.13 - Tuan 15
Nguyen Duy Khanh - 20225019 - 744469 - 20241  
*/ 
#include<iostream>
#include<bits/stdc++.h>
using namespace std;
    map<int, int> Map;
    int sum = 0;
    int count_chain = 0;
int main(){
    ios_base::sync_with_stdio(false); cin.tie(NULL);
    string s;
    cin>>s;
    Map.insert({0, 1});
    int l = s.length();
    for (int i=0; i<l; i++){
        if (s[i] == '0') sum += -1;
        else sum += 1;
        count_chain += Map[sum];
        Map[sum]++;
    }
    cout<<endl;
    cout<<count_chain;
    return 0;
}
/******************** 
Nguyen Duy Khanh - 20225019  
Ma lop TH: 744469 
********************/
