/*  
Bai 3.3 - Tuan 13 
Nguyen Duy Khanh - 20225019 - 744469 - 20241  
*/ 
#include<iostream>
#include<cstring>
#include<climits>

using namespace std;

#define MAX 100

int n, c[MAX][MAX];
int cmin = INT_MAX;
int best = INT_MAX;
int curr;
int mark[MAX];
int x[MAX];

void input(){
	std::cin>>n;
	for (int i = 1; i <= n; i++){
		for (int j = 1; j <= n; j++){
			std::cin >> c[i][j];
			if (c[i][j] > 0) cmin = std::min(cmin, c[i][j]);
		}
	}
}

void Try(int k){
	for (int i = 2; i <= n; i++){
		if (!mark[i]){
			mark[i] = 1;
			x[k] = i;
			curr = curr + c[x[k - 1]][i];
			if (k == n){
				if (curr + c[x[n]][1] < best){
					best = curr + c[x[n]][1];
				}
			}
			else {
				if (curr > best) return;
				else Try(k + 1);
			}
			mark[i] = 0;
			curr -= c[x[k - 1]][i];
		}
	}
}

int main(){
	/******************** 
    Nguyen Duy Khanh - 20225019  
    Ma lop TH: 744469 
    ********************/ 
	input();
	x[1] = 1;
	Try(2);
	std::cout<<best;
	return 0;
}