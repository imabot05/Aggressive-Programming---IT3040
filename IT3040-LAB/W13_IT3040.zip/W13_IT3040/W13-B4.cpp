/*  
Bai 3.4 - Tuan 13 
Nguyen Duy Khanh - 20225019 - 744469 - 20241  
*/ 
#include<bits/stdc++.h>

using namespace std;
int a[1000], n;
int mem[1000];

void init(){
	memset(mem, -1, sizeof(mem));
}

// Dynamic programming
// lis(i) returns the longest increasing subsequence from index 0 to index i
int lis(int i){
	// If mem[i] is calculated, return 
	if (mem[i] != -1) return mem[i]; 
	mem[i] = 1;
	for (int j = 0; j < i; j++){
		if (a[j] < a[i]){
			mem[i] = max(lis(j) + 1, mem[i]);
		}
	}
	return mem[i];
}

// Trace the solution
void trace(int i){
	for (int j = 0; j < i; j++){
		if (a[j] < a[i] && mem[i] == 1 + mem[j]){
			trace(j);
			break;
		}
	}
	std::cout<<a[i]<<" ";
}

int main(){
	/******************** 
    Nguyen Duy Khanh - 20225019  
    Ma lop TH: 744469 
    ********************/ 
	init();
	std::cin>>n;
	for (int i = 0; i < n; i++){
		std::cin>>a[i];
	}
	int res = 1, pos = 0;
	for (int i = 1; i < n; i++){
		if (res < lis(i)){
			res = lis(i);
			pos = i;
		}
	}
	std::cout<<res<<std::endl;
	trace(pos);
	return 0;
}