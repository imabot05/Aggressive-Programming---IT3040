/*  
Bai 3.2 - Tuan 13 
Nguyen Duy Khanh - 20225019 - 744469 - 20241  
*/  
#include<iostream>
#include<vector>

const int MAXN = 101;
int n;

int X[MAXN], Y[MAXN];
bool marked[MAXN][MAXN];

const int hx[] = {1,1,2,2,-1,-1,-2,-2};
const int hy[] = {2,-2,1,-1,2,-2,1,-1};

void print_sol(){
	for (int i = 1; i <= n * n; i++){
		std::cout <<"(" << X[i] << " " << Y[i] << ")" <<std::endl;
	}
	exit(0);
}

void Try(int k);
void Try(int k){
	for (int i = 0; i < 8; i++){
		int newX = X[k - 1] + hx[i];
		int newY = Y[k - 1] + hy[i];
		if (newX >= 1 && newX <= n && newY >= 1 && newY <= n && !marked[newX][newY]){
			X[k] = newX;
			Y[k] = newY;
			marked[newX][newY] = true;
			if (k == n * n) print_sol();
			else {
				Try(k + 1);
			}
			marked[newX][newY] = false;
		} 
	}
}


int main(){
	/******************** 
    Nguyen Duy Khanh - 20225019  
    Ma lop TH: 744469 
    ********************/ 
	std::cin >> n;
	marked[1][1] = true;
	X[1] = Y[1] = 1;
	Try(2);
	return 0;
} 