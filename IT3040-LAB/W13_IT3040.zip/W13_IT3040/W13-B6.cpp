/*  
Bai 3.6 - Tuan 13 
Nguyen Duy Khanh - 20225019 - 744469 - 20241  
*/ 
#include<iostream>
using namespace std;

int gcd(int a, int b);
int gcd2(int a, int b);

int gcd(int a, int b){
	if (b == 0) return a;
	return gcd(b, a % b);
}

int gcd2(int a, int b){
	while (a != b){
		if (a > b) a -= b;
		else b -= a;
	}
	return a;
}

int main(){
	/******************** 
    Nguyen Duy Khanh - 20225019  
    Ma lop TH: 744469 
    ********************/ 
	int a, b;
	std::cin >> a >> b;
	std::cout<<gcd(a, b)<<std::endl;
	std::cout<<gcd2(a, b)<<std::endl;
}