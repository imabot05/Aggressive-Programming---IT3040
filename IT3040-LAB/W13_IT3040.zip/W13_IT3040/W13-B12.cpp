/*  
Bai 3.12 - Tuan 13 
Nguyen Duy Khanh - 20225019 - 744469 - 20241  
*/ 
#include<iostream>
#include<vector>
#include<cstring>

using namespace std;
const int MAXN = 101;
int n, k, m;
vector<vector<int>> vt;
int X[MAXN], res;
bool visited[MAXN];

void input(){
	cin >> n >> k;
	cin >> m;
	vt.resize(n+1);
	for (int i = 0; i < m; i++){
		int u, v;
		cin >> u >> v;
		vt[u - 1].push_back(v - 1);
		vt[v - 1].push_back(u - 1);
	}
	for (int i = 0; i < n; i++){
		visited[i] = false;
	}
	res = 0;
}

bool check(int a, int i){
	if (a == 0) return true;
	if (visited[i] == true) return false;
	int index = 0;
	for (int j = 0; j < vt[X[a-1]].size(); j++){
		if (i == vt[X[a-1]][j]) return true;
	}
	return false;
}

void solution(){
    res++;
}

void Try(int a){
	for (int i = 0; i < n; i++){
		if (check(a, i)){
			visited[i] = true;
			X[a] = i;
			if(a == k) solution();
            else Try(a+1);
            visited[i] = false;
		}
	}
}

int main(){
    /*
    Nguyen Duy Khanh - 20225019
    Ma lop: 738919
    */
    input();
    Try(0);
    cout << res / 2;
}

