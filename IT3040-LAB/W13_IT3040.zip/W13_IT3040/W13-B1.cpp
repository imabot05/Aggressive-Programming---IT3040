/*  
Bai 3.1 - Tuan 13 
Nguyen Duy Khanh - 20225019 - 744469 - 20241  
*/  
#include<bits/stdc++.h>
using namespace std;
int lucas(int n){
	if (n == 0) return 2;
	if (n == 1) return 1;
	return lucas(n - 1) + lucas(n - 2);
} 

int main(){
	 /******************** 
    Nguyen Duy Khanh - 20225019  
    Ma lop TH: 744469 
    ********************/ 
	std::cout << lucas(5) << std::endl;
	std::cout << lucas(10) << std::endl;
	std::cout << lucas(30) << std::endl;
	return 0;
}