/*  
Bai 3.10 - Tuan 13 
Nguyen Duy Khanh - 20225019 - 744469 - 20241  
*/ 
#include<iostream>
#include<vector>

using namespace std;
const int MAXN = 21;

int N, H;
int x[MAXN], s[MAXN], cnt = 0;

void inp(){
    cin >> N >> H;
    for (int i = 0; i < N; i++){
        s[i] = 0;
    }
    for (int i = 0; i < N; i++){
        x[i] = 0;
    }
}

int checkHamming(int a[], int b[]){
    int length = N;
    int cnt = 0;
    for (int i = 0; i < length; i++){
        if (a[i] != b[i]) cnt += 1;
    }
    return cnt;
}

void solution(){
    if (checkHamming(x, s) == H){
        for (int i = 0; i < N; i++){
            cout << x[i];
        }
        cout << endl;
    }
}

void Try(int i){
    for (int j = 0; j <= 1; j++){
        x[i] = j;
        if (i == N - 1) solution();
        else Try(i + 1);
    }
}

int main(){
/******************** 
Nguyen Duy Khanh - 20225019  
Ma lop TH: 744469 
********************/ 
    int T;
    cin >> T;
    while (T--){
        inp();    
        Try(0);
    }
}