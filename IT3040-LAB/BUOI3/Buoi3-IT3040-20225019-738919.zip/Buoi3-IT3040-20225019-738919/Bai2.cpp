#include<bits/stdc++.h>
using namespace std;
int n;
int X[100], Y[100];
int mark[100][100];

const int hx[] = {1,1,2,2,-1,-1,-2,-2};
const int hy[] = {2,-2,1,-1,2,-2,1,-1};
void print_sol(){
	for (int i = 1; i <= n*n; i++){
		printf("(%d %d)\n", X[i], Y[i]);
	}
	exit(0);
}

void Try(int k){
	for (int i = 0; i < 8 ; i++){
		int xx = X[k-1] + hx[i];
		int yy = Y[k-1] + hy[i];
		if (xx >= 1 && xx <= n && yy >= 1 && yy <= n && mark[xx][yy] == 0){
			X[k] = xx;
			Y[k] = yy;
			mark[xx][yy] = 1;
			if (k == n*n) print_sol();
			else Try(k + 1);
			mark[xx][yy] = 0;
		}
	}
}
int main(){
	std::cin>>n;
	mark[1][1] = 1;
	X[1] = Y[1] = 1;
	Try(2);
	return 0;
}
