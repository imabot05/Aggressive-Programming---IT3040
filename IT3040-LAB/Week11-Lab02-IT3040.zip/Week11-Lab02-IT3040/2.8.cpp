#include<iostream>
#include<vector>
#include<algorithm>
#include<numeric>
using namespace std;
int main(){
	/* Nguyen Duy Khanh - 20225019
	   Ma lop: 738919 */
	int val1, val2;
	cin>>val1>>val2;
	vector<vector<int>>a = {{1,3,7},{2,3,4,val1},{9,8,15},{10, val2},};
	sort(a.begin(), a.end(), [](vector<int>vec1, vector<int>vec2){
		int s1 = 0, s2 = 0;
		for (auto a: vec1) s1 += a;
		for (auto a: vec2) s2 += a;
		return s1 > s2;
	});
	
	for (const auto &x: a){
		for (int it: x){
			cout<<it<<" ";
		}
		cout<<endl;
	}
	return 0;
}
