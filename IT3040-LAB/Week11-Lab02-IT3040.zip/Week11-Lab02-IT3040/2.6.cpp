
/* 
Bai 2.6 - Tuan 11
Nguyen Duy Khanh - 20225019 - 744469 - 20241 
*/ 
#include <stdio.h>
void print(int n) {
   printf("n=%d\n", n);
}
int mul3plus1(int n) {
   return n * 3 + 1;
}
int div2(int n) {
   return n / 2;
}
// Khai bao cac tham so cho cac con tro ham
void simulate(int n, int (*odd)(int), int (*even)(int), void (*output)(int))  {
   (*output)(n);
   if (n == 1) return;
   if (n % 2 == 0) {
       n = (*even)(n);
   } else {
       n = (*odd)(n);
   }
   simulate(n, odd, even, output);
}
int main() {
   int (*odd)(int) = NULL;
   int (*even)(int) = NULL;
   /********************
   Nguyen Duy Khanh - 20225019 
   Ma lop TH: 744469
   ********************/
   odd = mul3plus1;
   even = div2;
   int n;
   scanf("%d", &n);
   simulate(n, odd, even, print);
   return 0;
}