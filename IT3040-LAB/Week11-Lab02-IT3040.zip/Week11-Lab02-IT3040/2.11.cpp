/* 
Bai 2.11 - Tuan 11
Nguyen Duy Khanh - 20225019 - 744469 - 20241 
*/ 
#include <bits/stdc++.h>
using namespace std;
typedef struct dathuc {
    int n;
    int *a;
}dathuc;

dathuc operator * (dathuc x, dathuc y) {
    dathuc c;
    int bac_x = x.n;
    int bac_y = y.n;
    c.n = bac_x + bac_y;
    c.a = new int[c.n + 1];
    for(int i = 0 ; i <= c.n ; i++) {
        c.a[i] = 0;
        for(int j = 0 ; j <= bac_x ; j++) {
            if(((c.n - i) - (x.n - j)) <= y.n && ((c.n - i) - (x.n - j)) >= 0) {
                c.a[i] += x.a[j] * y.a[y.n - (c.n - i) + (x.n - j)];
            }
        }
    }
    return c;
}
int main() {
    /********************
    Nguyen Duy Khanh - 20225019 
    Ma lop TH: 744469
    ********************/
    dathuc x, y;
    cin>>x.n;
    x.a = new int[x.n + 1];
    for(int i = 0 ; i <= x.n ; i++) {
        cin>>x.a[i];
    }
    cin>>y.n;
    y.a = new int[y.n + 1];
    for(int i = 0 ; i <= y.n ; i++) {
        cin>>y.a[i];
    }
    dathuc c = x * y;
    int res = 0; 
    for(int i = 0 ; i <= c.n ; i++) {
        res = res ^ c.a[i];
    }
    cout<<res;
}
