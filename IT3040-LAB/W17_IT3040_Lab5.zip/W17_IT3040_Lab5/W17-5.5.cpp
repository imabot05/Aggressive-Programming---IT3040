/*   
Bai 5.5 - Tuan 17 
Nguyen Duy Khanh - 20225019 - 744469 - 20241   
*/  
#include <bits/stdc++.h>
using namespace std;
int main(){
	/********************  
	Nguyen Duy Khanh - 20225019   
	Ma lop TH: 744469  
	********************/ 
    int n;
    cin >> n;
    bool found = false;
    while(n--){
        int a;
        cin >> a;
        if ((a % 4 == 0 && a % 100 != 0) || (a % 400 == 0)){
        	found = true;
            cout<<"Yes";
            return 0;	
		}
    }
    cout << "No";
}
