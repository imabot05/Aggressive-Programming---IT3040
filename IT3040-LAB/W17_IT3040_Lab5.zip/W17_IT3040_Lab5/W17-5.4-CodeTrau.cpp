#include<iostream>
#include<vector>
#include<algorithm>
#include<numeric>

using namespace std;

const int INF = 1e9 + 7;
int m, n, smin = INF;
long long S = 0;
int cmin = INF;
int x[100];
int c[100][100];
vector<bool> flag(100, false);

int main(){
	cin >> n >> m;
	int x, y, w;
	vector<vector<int>> c(n, vector<int>(n, INF));
	while (m--){
		int x, y, w;
		cin >> x >> y >> w;
		c[x - 1][y - 1] = min(c[x - 1][y - 1], w);
	}
	long long ans = INF;
	vector<int> p(n);
	iota(p.begin(), p.end(), 0);
	do {
		long long sum = 0;
		for (int i = 0; i < n - 1; i++){
			cout << p[i] << " ";
			sum += c[p[i]][p[i + 1]];
		}
		cout << p[n - 1] << " ";
		sum += c[p[n - 1]][0];
		cout << ans << " " << sum;
		cout << endl;
		ans = min(ans, sum);
	} while (next_permutation(p.begin() + 1, p.end()));
	cout << ans << endl;
	return 0;
}