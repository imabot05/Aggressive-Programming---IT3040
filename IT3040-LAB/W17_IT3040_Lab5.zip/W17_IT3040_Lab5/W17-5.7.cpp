/*   
Bai 5.7 - Tuan 17 
Nguyen Duy Khanh - 20225019 - 744469 - 20241   
*/  
#include<bits/stdc++.h>
using namespace std;
int main(){
	/********************  
	Nguyen Duy Khanh - 20225019   
	Ma lop TH: 744469  
	********************/ 
	int n;
	cin >> n;
	int ans = 0, sum = 0;
	while (n--){
		int k, t;
		cin >> k >> t;
		while (k--){
			int a;
			cin >> a;
			sum += t * a;
			ans = max(ans, -sum);
		}
	}
	cout << ans;
	return 0;
}