#include<stdio.h>
#include<stdlib.h>
/*
Bai 1.5 - Tuan 8
Nguyen Duy Khanh - 20225019 - 744469 - 20241
*/
double *maximum(double *a, int size){
	double *max;
	max = a;
	if (a == NULL) return NULL;
	/************
	Nguyen Duy Khanh - 20225019
	Ma lop TH: 744469 - 20241
	************/
	for (int i = 0; i < size; i++){
		if (*(a + i) > *max){
//			*max = *(a + i);
			max = &a[i];
		}
	}
	return max;
}

int main(){
	double arr[] = {1., 10., 2., -7., 25., 3.};
	double *max = maximum(arr, 6);
	printf("%.0f", *max);
	return 0;
}