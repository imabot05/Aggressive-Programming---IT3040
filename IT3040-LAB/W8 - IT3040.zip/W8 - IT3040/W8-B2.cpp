/*
Bai 1.2 - Tuan 8
Nguyen Duy Khanh - 20225019 - 744469 - 20241
*/
#include <stdio.h>
int main(){
    int a[7]= {13, -355, 235, 47, 67, 943, 1222}; 
    printf("Address of first five elements in memory.\n");
    for (int i = 0; i < 5; i++){
    	printf("\ta[%d] ", i);
	}
	printf("\n");
    /************
    Nguyen Duy Khanh - 20225019
    Ma lop TH: 744469
	************/
	// In ra dia chi cua 5 phan tu dau tien trong mang
    for (int i = 0; i < 5; i++){
    	printf("%p ", &a[i]);
	}
           
    return 0;
}