/*
Bai 1.4 - Tuan 8
Nguyen Duy Khanh - 20225019 - 744469 - 20241
*/
#include<stdio.h>
#include<stdlib.h>
int counteven(int *arr, int size){
	int count = 0;
	/************
	Nguyen Duy Khanh - 20225019
	Ma lop TH: 744469 - 20241
	*************/
	for (int i = 0; i < size; i++){
		if (*(arr + i) % 2 == 0){
			count += 1;
		}
	}
	return count;
}

void solve(){
	int arr[] = {1, 5, 4, 8, 10, 6, 7, 2};
	printf("%d", counteven(arr, sizeof(arr) / sizeof(arr[0])));
}
int main(){
	solve();
	return 0;
}