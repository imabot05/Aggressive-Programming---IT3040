#include<stdio.h>
#include<stdlib.h>
/*
Bai 1.6 - Tuan 8
Nguyen Duy Khanh - 20225019 - 744469 - 20241
*/
void reversearray(int arr[], int size){
	int l = 0, r = size - 1, tmp;
	while (l <= r){
		tmp = arr[l];
		arr[l] = arr[r];
		arr[r] = tmp;
		l++;
		r--;
	}
}

void ptr_reversearray(int *arr, int size){
 	int l = 0, r = size - 1, tmp;
 	while (l <= r){
 		tmp = *(arr + l);
 		*(arr + l) = *(arr + r);
 		*(arr + r) = tmp;
 		l++;
 		r--;
	 }
}
/************
Nguyen Duy Khanh - 20225019
Ma lop TH: 744469 - 20241
************/

int main(int argc, const char ** argv){
	int arr[] = {9, 3, 5, 6, 2, 5};
	reversearray(arr, sizeof(arr) / sizeof(arr[0]));
	for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); i++) {
		printf("%d ", arr[i]);
	}
	printf("\n");
	int arr2[] = {4, -1, 5, 9};
	ptr_reversearray(arr2, sizeof(arr2) / sizeof(arr2[0]));
	for (int i = 0; i < sizeof(arr2) / sizeof(arr2[0]); i++) {
		printf("%d ", arr2[i]);
	}
}