/*
Bai 1.7 - Tuan 8
Nguyen Duy Khanh - 20225019 - 744469 - 20241
*/
#include<stdio.h>
void solve(){
	/************
	Nguyen Duy Khanh - 20225019
	Ma lop TH: 744469 - 20241
	************/
	int n;
	printf("Enter the number of elements:\n");
	scanf("%d", &n);
	int arr[n + 1];
	for (int i = 0; i < n; i++){
		scanf("%d", &arr[i]);
	}
	printf("The input array is:\n");
	for (int i = 0; i < n; i++){
		printf("%d ", *(arr + i));
	}
	
	for (int i = 0; i < n - 1; i++){
		for (int j = i + 1; j < n; j++){
			if (*(arr + i) > *(arr + j)){
				int tmp = *(arr + i);
				*(arr + i) = *(arr + j);
				*(arr + j) = tmp;
			}
		}
	}
	printf("\nThe sorted array is:\n");
	for (int i = 0 ; i < n ; i++){
		printf("%d ", arr[i]);
	}
}

int main(){
	solve();
	return 0;
}