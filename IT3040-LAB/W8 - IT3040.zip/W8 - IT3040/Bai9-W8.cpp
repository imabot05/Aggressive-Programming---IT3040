/*
Bai 1.9 - Tuan 8
Nguyen Duy Khanh - 20225019 - 744469 - 20241
*/
#include<iostream>
#include<stdlib.h>
int n;
int *a;

void allocateMem(int **a, int n){
	*a = new int[n];
}

// Allocation
void input(){
	std::cin>>n;
	allocateMem(&a, n);
	for (int i = 0; i < n; i++){
		std::cin>>a[i];
	}
}


void freeMem(int *a){
	delete[] a;
}

// Print subarray from index start to index end
void printSubarray(int *a, int start, int end){
	for (int i = start; i <= end; i++){
		std::cout<<a[i]<<" ";
	}
	std::cout<<std::endl;
}

int main(int argc, const char** argv){
	/***********
	Nguyen Duy Khanh - 20225019
    Ma lop TH: 744469	
	************/
	input();
	for (int i = 0; i < n; i++){
		for (int j = i; j < n; j++){
			printSubarray(a, i, j);
		}
	}
	freeMem(a);
}