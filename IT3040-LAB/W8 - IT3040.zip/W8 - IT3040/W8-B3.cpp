/*
Bai 1.3 - Tuan 8
Nguyen Duy Khanh - 20225019 - 744469 - 20241
*/
#include <stdio.h> 
int main() 
{ 
	int x, y, z; 
	int *ptr; 
	scanf("%d %d %d", &x, &y, &z); 
	printf("Here are the values of x, y, and z:\n"); 
	printf("%d %d %d\n", x, y, z); 
	/***************** 
	Nguyen Duy Khanh - 20225019
	Ma lop TH: 744469 
	*****************/ 
	ptr = &x;
	*ptr = *ptr + 100;
	ptr = &y;
	*ptr = *ptr + 100;
	ptr = &z;
	*ptr = *ptr + 100;
	printf("Once again, here are the values of x, y, and z:\n"); 
	printf("%d %d %d\n", x, y, z); 
	return 0; 
}     