int counteven(int* arr, int size){
    int count = 0;
    /*****************
    Nguyen Duy Khanh - 20225019
    *****************/
    for (int i = 0; i < size; i++)
    {
    	if (*(arr+i) % 2 == 0)
    	count++;
	}
    return count;    
}
