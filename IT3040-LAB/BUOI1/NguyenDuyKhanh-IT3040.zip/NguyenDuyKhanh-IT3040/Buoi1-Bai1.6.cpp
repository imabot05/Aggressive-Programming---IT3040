#include<stdio.h>
int main(){
	/************
	Nguyen Duy Khanh - 20225019
	************/
	int n;
	printf("Enter the number of elements: ");
	scanf("%d", &n);
	int arr[100];
	for (int i = 0 ; i < n ; i++){
		scanf("%d", &arr[i]);
	}
	printf("The input array is:\n");
	for (int i = 0 ; i < n ; i++){
		printf("%d ", arr[i]);
	}
	for (int i = 0 ; i < n - 1 ; i++){
		for (int j = i + 1 ; j < n ; j++){
			if (*(arr+i) > *(arr+j)){
				int tmp = *(arr+i);
				*(arr+i) = *(arr+j);
				*(arr+j) = tmp;
			}
		}
	}
	printf("\nThe sorted array is:\n");
	for (int i = 0 ; i < n ; i++){
		printf("%d ", arr[i]);
	}
	return 0;
}
