# include <stdio.h>
int main(){
    int x, y, z;
    int* ptr;
    printf("Enter three integers: ");
    scanf("%d %d %d", &x, &y, &z);
    printf("\nThe three integers are:\n");
    ptr = &x;
    printf("x = %d\n", *ptr); // Gan dia chi cua bien x cho con tro ptr
    //***************
    // Nguyen Duy Khanh - 20225019
    ptr = &y;
    printf("y = %d\n", *ptr); // Gan dia chi cua bien y cho con tro ptr
    ptr = &z;
    printf("z = %d\n", *ptr); // Gan dia chi cua bien z cho con tro ptr
    //***************
    return 0;
}




