// Nguyen Duy Khanh - 20225019
/*
Bai 1.2. Viet chuong trinh in ra dia chi cua 5 phan tu dau tien trong mang duoc dinh nghia sau day:
int a[7]= {13, -355, 235, 47, 67, 943, 1222};
Luu y:
De in dia chi con tro cac ban su dung ky tu dinh dang %p
De lay dia chi cua mot bien ta co the dung phep toan &
*/
#include <stdio.h>
int main(){
    int a[7]= {13, -355, 235, 47, 67, 943, 1222}; 
    printf("address of first five elements in memory.\n");
    for (int i=0; i<5;i++)  printf("\ta[%d] ",i);
    printf("\n");

    /*****************
    Nguyen Duy Khanh - 20225019
    *****************/
    for (int i = 0 ; i < 5 ; i++)
  printf("%p ", &a[i]);       
    return 0;
}
