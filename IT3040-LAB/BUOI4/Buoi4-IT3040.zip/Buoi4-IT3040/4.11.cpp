
#include<bits/stdc++.h>
using namespace std;
    int n, s;
    struct couple{
        int a;
        int k;
    };
    int sum = 0;     
    int died = 0;      
    couple wall[100001];
    stack<int> ST;
    priority_queue<int, vector<int>> PQ; 

bool compare(couple x, couple y){
    return x.k > y.k;
}

void process(){
    for (int i=0; i < n; i++){
        while (!PQ.empty() && PQ.top() > wall[i].k && s>0) {
            died += PQ.top();
            PQ.pop();
            s--;
        }
        int thuong = wall[i].a / wall[i].k;
        int du = wall[i].a % wall[i].k;
        if (du != 0) PQ.push(du);

        if (thuong <= s) {
            s -= thuong;
            died += thuong*wall[i].k;
        } else {
            died += s*wall[i].k;
            s = 0;
            break;
        }
    }
    while (s>0 && !PQ.empty()){
        died += PQ.top();
        s--;
        PQ.pop();
    }
}
int main(){
	/* 
	Nguyen Duy Khanh - 20225019
	Ma lop: 738919
	*/
    cin>>n>>s;
    for (int i=0; i < n; i++)
    {
        cin>>wall[i].a>>wall[i].k;
        sum += wall[i].a;
    }
    sort(wall, wall+n, compare); //Sap xep giam dan theo kha nang bao ve k
    process();
    cout<<endl;
    cout<<sum-died;
    return 0;
}
