#include<iostream>
using namespace std;
struct Node{
	int data;
	Node *next;
	Node(int data){
		this->data = data;
		next = NULL;
	}
};
Node *prepend(Node *head, int data){
	Node *temp = new Node(data);
	temp->next = head;
	head = temp;
	return head;
}
void print(Node *head){
	Node *tmp = head;
	while (tmp != NULL){
		std::cout<<tmp->data<<" ";
		tmp = tmp->next;
	}
	std::cout<<std::endl;
}
Node *reverse(Node *head){
	Node *prev = NULL;
	Node *current = head;
	Node *next = NULL;
	while (current != NULL){
		next = current->next;
		current->next = prev;
		prev = current;
		current = next;
	}
	head = prev;
	return head;
}
int main(){
    /* 
    Nguyen Duy Khanh - 20225019
    Ma lop: 738919
    */
	int n, u;
	std::cin>>n;
	Node *head = NULL;
	for (int i = 0; i < n ; i++){
		std::cin>>u;
		head = prepend(head, u);
	}
	std::cout<<"Original list: ";
	print(head);
	head = reverse(head);
	std::cout<<"Reversed list: ";
	print(head);
	return 0;
}

